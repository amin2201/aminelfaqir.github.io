<div align="center">
<h1>My Old Portfolio</h1>
<img  src="https://user-images.githubusercontent.com/32486682/177661402-950d65c4-c738-4422-9f76-5b6df9b3d0f7.gif" alt="nilooy portfolio"/>
</div>

## [New Portfolio](https://nilooy.dev)

## Usage

1. Install deps
```sh
npm install
```

2. Run local dev server
```sh
npm run dev
```

## Tech Stack
- Svelte
- Three.js



